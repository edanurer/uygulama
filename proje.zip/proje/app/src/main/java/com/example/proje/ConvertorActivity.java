package com.example.proje;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;

public class ConvertorActivity extends AppCompatActivity {

    private TextView txtbaslik;
    private TextView txtdecimal;
    private TextView txtbayt;
    private TextView txtcelcius;
    private TextView txtsonuc;
    private TextView txtsonuc2;
    private TextView txtsonuc3;
    private TextView txtdeger;
    private TextView txtdeger2;
    private TextView txtdeger3;
    private TextInputEditText txtinput;
    private TextInputEditText txtinput2;
    private TextInputEditText txtinput3;
    private Spinner spinner;
    private Spinner spinner2;
    private RadioButton radioF;
    private RadioButton radioK;
    private Button btnback;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_convertor);

        txtbaslik = findViewById(R.id.baslik);
        txtdecimal = findViewById(R.id.decimal5);
        txtbayt = findViewById(R.id.bayt);
        txtcelcius = findViewById(R.id.celcius);
        txtsonuc = findViewById(R.id.sonuc);
        txtsonuc2 = findViewById(R.id.sonuc2);
        txtsonuc3 = findViewById(R.id.sonuc4);
        txtdeger = findViewById(R.id.deger);
        txtdeger2 = findViewById(R.id.deger2);
        txtdeger3 = findViewById(R.id.deger3);
        txtinput = findViewById(R.id.input);
        txtinput2 = findViewById(R.id.input2);
        txtinput3 = findViewById(R.id.input3);
        spinner = findViewById(R.id.spinner);
        spinner2 = findViewById(R.id.spinner2);
        radioF = findViewById(R.id.fahrenayt);
        radioK = findViewById(R.id.kelvin);
        btnback = findViewById(R.id.back);

        btnback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ConvertorActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });



    }

}
