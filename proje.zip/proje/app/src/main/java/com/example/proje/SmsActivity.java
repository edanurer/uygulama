package com.example.proje;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;

public class SmsActivity extends AppCompatActivity {


    private TextView baslik2;
    private TextView txxttel;
    private TextInputEditText txttelno;
    private TextInputEditText txteposta;
    private Button txtmesaj;
    private Button btngonder;
    private Button btngeri;


    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms);

        baslik2 = findViewById(R.id.baslik2);
        txxttel = findViewById(R.id.tel);
        txtmesaj = findViewById(R.id.mesaj);
        txttelno = findViewById(R.id.telno);
        txteposta = findViewById(R.id.eposta);
        btngonder = findViewById(R.id.gonder);
        btngeri = findViewById(R.id.back3);

        btngeri.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(SmsActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });


    }

}
