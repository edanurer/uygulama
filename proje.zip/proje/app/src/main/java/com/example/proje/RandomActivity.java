package com.example.proje;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;

public class RandomActivity extends AppCompatActivity {


    private TextView baslik3;
    private TextView txxadet = findViewById(R.id.adet);
    private TextView txtmaks;
    private TextView txtmin;
    private TextInputEditText txtinputA;
    private TextInputEditText txtinputmaks;
    private TextInputEditText txtinputmin;
    private Button btnmain;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_random);

        baslik3 = findViewById(R.id.baslik3);
        txtmaks = findViewById(R.id.maks);
        txtmin = findViewById(R.id.min);
        txtinputA = findViewById(R.id.inputA);
        txtinputmaks = findViewById(R.id.inputmax);
        txtinputmin = findViewById(R.id.inputmin);
        btnmain = findViewById(R.id.main);

        btnmain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(RandomActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });


    }
}
